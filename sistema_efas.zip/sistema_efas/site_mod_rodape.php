<div class="span12">
    &copy; 2015 Sistema de Inscrições - Encontro Fraterno Auta de Souza
</div> <!-- /span12 -->

<script src="js/bootstrap.js"></script>
<script src="js/base.js"></script>