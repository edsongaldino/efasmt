<?php
session_start();

require_once("ferramenta/configuracoes.php");
require_once("ferramenta/funcao_php.php");

verifica_sessao();
?>