<?php
function fecha_mysql() {
	mysql_close();
}
?>