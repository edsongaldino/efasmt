<?php
function notificacao_email_atendimentofinalizado($codigo_atendimento) {
	return true;
}
?>